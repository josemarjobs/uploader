require "bundler"

Bundler.require
Bundler.require :test

require "minitest/autorun"