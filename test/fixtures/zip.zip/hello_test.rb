require "test_helper"

describe "Hello" do
  it "asserts something" do
    assert true
  end
end